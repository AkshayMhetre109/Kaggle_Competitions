import os
import pandas as pd
from sklearn.model_selection import train_test_split

train_path = os.path.abspath("data/train_4.csv")
val_path = os.path.abspath("data/val_4.csv")

print(f"🔍 Looking for training file at:\n{train_path}")

if not os.path.exists(train_path):
    print("❌ ERROR: train_4.csv not found! Check your 'data' folder path.")
    exit()

# Load data
df = pd.read_csv(train_path)
print(f"✅ Loaded {len(df)} rows from train_4.csv")

# Split
train_df, val_df = train_test_split(df, test_size=0.2, random_state=42)

# Save files
train_df.to_csv(train_path, index=False)
val_df.to_csv(val_path, index=False)

print(f"✅ Created validation file at:\n{val_path}")
print(f"📊 Train size: {len(train_df)}, Val size: {len(val_df)}")
